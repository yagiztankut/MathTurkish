Bu, Yağız Tankut Tarafından Geliştirilen Bir Türkçe
Matematik Kütüphanesidir. Özellikle Yeni Başlayanlar
İçin Geliştirlien Bu Kütüphane Hesaplamaları Otomatik
Olarak Yapmanızı Sağlamaktadır.

İletişim: isletmeyap@gmail.com