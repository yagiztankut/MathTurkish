import setuptools
setuptools.setup(
	name="MathTurkish",
	version="1.0",
	author="Yağız Tankut",
	description="Turkish Math Library",
)